#!/usr/bin/env python
# coding: utf-8

# Parallel Processing Concepts Group Project
# By Taylor Hartman, Kendra Givens, and Scott Hartsell
# CSCI 4330/6330 w/ Dr. Khem Poudel

# ----------------------------------------------------

# In[1]:


# Date/time module
from datetime import datetime

import threading

# In[2]:


# Importing .csv module to write to file
import csv
from csv import writer
# Lists for variable to be written to the data files
time_list = []
metrics_list = []
# file = open('Parallel_Processing_Conecpts_Python_Threads.csv', 'a')


# Apache Spark Instantiation

# In[3]:


# Import to find Spark on PC
import findspark
findspark.init()
findspark.find()

# Importing pyspark and Spark Session
import pyspark
from pyspark.sql import SparkSession

# Import garbage collector for deleting dataframes
import gc

# All other imports


# Creating a sprark session
spark = SparkSession.builder.master("local[1]").appName("ECG").getOrCreate()


# Loading Dataset

# In[4]:


# Import data into dataframe
df = spark.read.csv("./ecg.csv", header=False, inferSchema=True)


# Splitting of Data Classifications

# In[5]:


# Last column holds classification labels, rename to "label"
df = df.withColumnRenamed(df.columns[-1], "label")


# In[6]:


# Creating a new data frame with all '1' classification labels and corresponding data
# this does not affect df
df2 = df.filter(df['label'] == '1')


# In[7]:


# Overwriting original dataframe with all '0' classification labels and corresponding data
df = df.filter(df['label'] == '0')


# Classification Ratio Balancing

# In[8]:


# Seeded random split to get data with label of 1 as close to the number of data with 0 as possible (2079)
df3, df4 = df2.randomSplit([0.30, 0.70], seed=1000)


# In[9]:


# Using the union method to add the dataframe with only 1's in it to the dataframe that has only 0's
df = df.union(df4)


# In[10]:


# Deleting unused dataframes
del df2
del df3
del df4

# Using the garbage collector to free the memory
gc.collect()


# Vectorization of Spark Data Frame

# In[11]:


# Creating a list of all column names that are features (minus the last column which is the label)
features_list = df.columns[:-1]


# In[12]:


# Importing the vector assembler module from pyspark
from pyspark.ml.feature import VectorAssembler

# Using the VectorAssembler method to create a DenseVector of features called "feature_vector"
feature_vector_assembler = VectorAssembler(inputCols=features_list,
                                           outputCol="feature_vector")

# Transforming the vector and mounting it to the dataframe
df = feature_vector_assembler.transform(df)


# Normalization of Spark Data Frame

# In[13]:


# Standardizing the data
from pyspark.ml.feature import StandardScaler

# Creating a scalar with the input being the feature_vector and output scaled_feature_vector
# We choose the options of using standard deviation and mean to normalize the data
scaler = StandardScaler(inputCol="feature_vector",
                        outputCol="scaled_feature_vector",
                        withStd=True, withMean=True)

# Fitting the data to the scalar
scaler = scaler.fit(df)

# Transforming and mounting the scaled data to the dataframe
df = scaler.transform(df)


# Transforming the Data Frame for Machine Learning Use

# In[14]:


# Creating a dataframe for the model to fit to
model_df = df.select("scaled_feature_vector","label")


# In[15]:


# Splitting the data into training, test, and validation dataframes using a the randomSplit method with a seed to standardize the output sizes across multiple runs of the file
training_df, test_df, validation_df = model_df.randomSplit([0.7, 0.2, 0.1], seed=22)


# Import Block

# Logistic Regression ML Model

# In[16]:


# Importing the Logistic Regression model from pyspark ml library
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import LinearSVC

LR_time = RF_time = SVC_time = datetime.now()

# In[17]:

def LR():
    begin = datetime.now()

    # Fitting the model and storing it to a variable
    log_reg = LogisticRegression(featuresCol="scaled_feature_vector", labelCol="label").fit(training_df)
    
    
    # Training the model with the training data and storing the predictions in a variable
    LR_train_results = log_reg.evaluate(training_df).predictions
    
    
    # Testing the model and storing the predictions to a variable
    LR_test_results = log_reg.evaluate(test_df).predictions
    
    
    # Get validation results
    LR_validation_results = log_reg.evaluate(validation_df).predictions
    
    
    # Get ending time and find model's real runtime
    end = datetime.now()
    LR_time = end - begin

    print("LR_time: ",LR_time)
	
    return


# Random Forest ML Model

def RF():
    # Get beginning runtime point
    begin = datetime.now()
    
    # Make the random forest model and fit with training data
    rf = RandomForestClassifier(labelCol="label", featuresCol="scaled_feature_vector", numTrees=12, featureSubsetStrategy='sqrt').fit(training_df)
    
    
    # Training the model with the training data and storing the predictions in a variable
    RF_train_results = rf.evaluate(training_df).predictions
    
    
    # Get the test data results
    RF_test_results = rf.evaluate(test_df).predictions
    
    
    # Get the validation data results
    RF_validation_results = rf.evaluate(validation_df).predictions
    
    
    # Get ending time and find model's real runtime
    end = datetime.now()
    
    RF_time = end - begin
    print("RF_time: ",RF_time)

    return

# Support Vector Classifier ML Model

def SVC():
    # Get beginning runtime point
    begin = datetime.now()
    
    # make the model
    svc = LinearSVC(featuresCol="scaled_feature_vector",labelCol="label",predictionCol="prediction",rawPredictionCol="rawPrediction").fit(training_df)
    
    
    # Training the model with the training data and storing the predictions in a variable
    SVC_train_results = svc.evaluate(training_df).predictions
    
    
    # Get the validation data results
    SVC_test_results = svc.evaluate(test_df).predictions
    
    
    # Get the validation data results
    SVC_validation_results = svc.evaluate(validation_df).predictions
    
    
    # Get ending time and find model's real runtime
    end = datetime.now()
    
    SVC_time = end - begin
    print("SVC_time: ",SVC_time)
	
    return


# Thread Creation for parallelized model training and evaluation
t1 = threading.Thread(target = LR, args=())
t2 = threading.Thread(target = RF, args=())
t3 = threading.Thread(target = SVC, args=())

# start the threads
main_begin = datetime.now()

t1.start()
t2.start()
t3.start()
t1.join()
t2.join()
t3.join()

main_end = datetime.now()

main_time = main_end - main_begin

time_file = open('Parallel_Processing_Conecpts_Python_Threads_Time.csv','a')
time_reader = csv.reader(time_file)
time_writer_obj = writer(time_file)
time_list.append(main_time.total_seconds())
time_writer_obj.writerow(time_list)


# Results Output

# In[64]:

print("Total time of training all models: " + str(main_time) + " seconds\n")


# with statement guarantees all data is written out to file and file object is closed properly
with open('results-python-parallel.txt', 'w', encoding="utf-8") as f:
    f.write("Total time of training all models: " + str(main_time) + " seconds\n")
    f.write('\n')


# In[63]:


# # Reading results into csv
with open('results-python-parallel.txt', 'r') as f:
  reader = csv.reader(f)
  with open('Parallel_Processing_Concepts_Python_Threads.csv', 'a', newline='') as w:
    writer = csv.writer(w)
    writer.writerow('\n')
    writer.writerows(reader)


# In[ ]:

f.close()
w.close()
time_file.close()

#close the spark session
spark.stop()

