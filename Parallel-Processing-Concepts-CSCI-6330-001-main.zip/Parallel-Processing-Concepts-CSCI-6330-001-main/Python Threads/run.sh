#!/bin/bash

for i in {1..100}
do
	echo "Run number: " $i
	python3 ./Project_Python_Threads.py &
	sleep 30
done