#!/bin/bash

for i in {1..100}
do
	echo "Run number: " $i
	mpirun -n 3 python Project_MPI.py &
	sleep 30
done