from mpi4py import MPI
import numpy
import time
from datetime import datetime
import csv
from csv import writer
import findspark
import pyspark
from pyspark.sql import SparkSession
import gc
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.feature import StandardScaler
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import LinearSVC
LR_time = RF_time = SVC_time = datetime.now()
main_begin = datetime.now()

time_list = []
metrics_list = []
# file = open('Parallel_Processing_Conecpts_MPI.csv', 'a')



##########################################################
# mpirun -n 3 python Project_MPI.py
##########################################################





comm = MPI.COMM_WORLD
rank = comm.Get_rank()

def LR(data_frame_list):
	training_df, test_df, validation_df = data_frame_list[0], data_frame_list[1], data_frame_list[2]
	
	begin = datetime.now()

    # Fitting the model and storing it to a variable
	log_reg = LogisticRegression(featuresCol="scaled_feature_vector", labelCol="label").fit(training_df)
    
    
    # Training the model with the training data and storing the predictions in a variable
	LR_train_results = log_reg.evaluate(training_df).predictions
    
    
    # Testing the model and storing the predictions to a variable
	LR_test_results = log_reg.evaluate(test_df).predictions
    
    
    # Get validation results
	LR_validation_results = log_reg.evaluate(validation_df).predictions
    
    
    # Get ending time and find model's real runtime
	end = datetime.now()
	LR_time = end - begin
	print("LR_time: ", LR_time)
    
	return

def RF(data_frame_list):
	training_df, test_df, validation_df = data_frame_list[0], data_frame_list[1], data_frame_list[2]
	
    # Get beginning runtime point
	begin = datetime.now()
    
    # Make the random forest model and fit with training data
	rf = RandomForestClassifier(labelCol="label", featuresCol="scaled_feature_vector", numTrees=12, featureSubsetStrategy='sqrt').fit(training_df)
    
    
    # Training the model with the training data and storing the predictions in a variable
	RF_train_results = rf.evaluate(training_df).predictions
    
    
    # Get the test data results
	RF_test_results = rf.evaluate(test_df).predictions
    
    
    # Get the validation data results
	RF_validation_results = rf.evaluate(validation_df).predictions
    
    
    # Get ending time and find model's real runtime
	end = datetime.now()
    
	RF_time = end - begin
	print("RF_time: ", RF_time)

	return

def SVC(data_frame_list):
	training_df, test_df, validation_df = data_frame_list[0], data_frame_list[1], data_frame_list[2]
	
    # Get beginning runtime point
	begin = datetime.now()
    
    # make the model
	svc = LinearSVC(featuresCol="scaled_feature_vector",labelCol="label",predictionCol="prediction",rawPredictionCol="rawPrediction").fit(training_df)
    
    
    # Training the model with the training data and storing the predictions in a variable
	SVC_train_results = svc.evaluate(training_df).predictions
    
    
    # Get the validation data results
	SVC_test_results = svc.evaluate(test_df).predictions
    
    
    # Get the validation data results
	SVC_validation_results = svc.evaluate(validation_df).predictions
    
    
    # Get ending time and find model's real runtime
	end = datetime.now()
    
	SVC_time = end - begin
	print("SVC_time: ", SVC_time)

	return

print('Preprocessing data on thread ',rank)
findspark.init()
findspark.find()
# Creating a sprark session
spark = SparkSession.builder.master("local[1]").appName("ECG").getOrCreate()
# Import data into dataframe
df = spark.read.csv("./ecg.csv", header=False, inferSchema=True)
df = df.withColumnRenamed(df.columns[-1], "label")
df2 = df.filter(df['label'] == '1')
df = df.filter(df['label'] == '0')
df3, df4 = df2.randomSplit([0.30, 0.70], seed=1000)
df = df.union(df4)
del df2
del df3
del df4
gc.collect()
features_list = df.columns[:-1]
feature_vector_assembler = VectorAssembler(inputCols=features_list, outputCol="feature_vector")
df = feature_vector_assembler.transform(df)
scaler = StandardScaler(inputCol="feature_vector", outputCol="scaled_feature_vector", withStd=True, withMean=True)
scaler = scaler.fit(df)
df = scaler.transform(df)
model_df = df.select("scaled_feature_vector","label")
training_df, test_df, validation_df = model_df.randomSplit([0.7, 0.2, 0.1], seed=22)
data_frame_list = [training_df, test_df, validation_df]
print("Preprocessing done.")

com1 = comm.isend(True, dest=0)
com2 = comm.isend(True, dest=1)
com3 = comm.isend(True, dest=2)
com1.wait()
com2.wait()
com3.wait()
main_begin = datetime.now()

if rank == 0:
	req = comm.irecv(source=0)
	data = req.wait()
	print("Training LR model")
	#main_begin = datetime.now()
	LR(data_frame_list)
elif rank == 1:
	req = comm.irecv(source=0)
	data = req.wait()
	print("Training RF model")
	#main_begin = datetime.now()
	RF(data_frame_list)
elif rank == 2:
	req = comm.irecv(source=0)
	data = req.wait()
	print("Training SVC model")
	#main_begin = datetime.now()
	SVC(data_frame_list)

main_end = datetime.now()
main_time = main_end - main_begin
print("Total run time: ", main_time)

time_file = open('Parallel_Processing_Conecpts_MPI.csv','a')
time_reader = csv.reader(time_file)
time_writer_obj = writer(time_file)
time_list.append(main_time.total_seconds())
time_writer_obj.writerow(time_list)
