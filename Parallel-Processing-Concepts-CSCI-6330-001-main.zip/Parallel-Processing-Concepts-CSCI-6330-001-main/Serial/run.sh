#!/bin/bash

for i in {1..100}
do
	echo "Run number: " $i
	python3 ./Project_Serial.py &
	sleep 60
done